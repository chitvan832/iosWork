//: Playground - noun: a place where people can play

import UIKit


let rectangleLength = 5
let rectangleBreadth = 5
let squareSide = 5
let pi = 3
let radius=5
let height=5



class Rectangle
{
    init(length : Int , breadth : Int)
    {
        print("Area of rectangle is \(length*breadth)")
        print("Perimeter of rectangle is \(2*length*breadth) \n")
    }
    
}

class Square
{
    init(side: Int)
    {
      print("Area of Square is \(side*side)")
        print("Perimeter of Square is \(4*side)\n")
    }
}


class Circle
{
    init(radius : Int)
    {
        print("area of circle is \(pi*radius*radius)")
        print("Perimeter of circle is \(2*pi*radius)\n")
    }
}

class Sphere
{
    init(radius : Int)
    {
        print("surface area of sphere is \(4*pi*radius*radius)")
        print("volume of sphere is \((4/3)*pi*radius*radius*radius)\n")
    }
}

class Cylinder
{
    init(radius: Int, height: Int)
    {
        let temp=height+radius
        print("surface area of cylinder is \(2*pi*radius*temp)")
        print("volume of cylinder is \(pi*radius*radius*height)\n")
    }
}

enum shapes: String
{
    case Rectangle,Square,Circle,Sphere,Cylinder

    static let allValues = [Rectangle,Square,Circle,Sphere,Cylinder]
}

for item in shapes.allValues{
    var shape = item

switch shape {
case shapes.Rectangle:
    let instanceOfRectangle = Rectangle(length: rectangleLength,breadth: rectangleBreadth)
case shapes.Square:
        let instanceOfSquare = Square(side:squareSide)
case shapes.Circle:
    let instanceOfCircle = Circle(radius: radius)
case shapes.Sphere:
    let instanceOfSphere = Sphere(radius: radius)
case shapes.Cylinder:
    let instanceOfCylinder = Cylinder(radius: radius,height: height)
    
    
    /*default:
    print("wrong input")*/
}
}